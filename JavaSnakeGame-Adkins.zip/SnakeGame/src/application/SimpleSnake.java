/*
 * CS1181-01
 * Instructor: Trevor Nartker
 * Lab Section 06
 * Brandon Adkins
 * Project 2
 */

package application;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javafx.scene.input.KeyEvent;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.text.Font;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

// many sources recommended using intelli download from eclipse marketplace to help with arcade games, 
// so I installed that. Code does not execute the same without it. 
public class SimpleSnake extends Application 
{
	// starting speed of the snake (increase every time you get 'food') 
	static int speed = 4;
	static int food = 0;
	// change the width of the play area
	static int Width = 32;
	// height of the play area
	static int Height = 32;
	static int Food1 = 0;
	static int Food2 = 0;
	//change the size of the game
	static int windowSize = 25;
	// direction the snake will start moving in
	static Dir direction = Dir.right;
	static boolean death = false;
	// to set food in random spots
	static Random rando = new Random();
	static List<snakeBits> snake = new ArrayList<>();

	public enum Dir 
	{
		left, right, up, down
	}

	public static class snakeBits 
	{
		int a;
		int b;

		public snakeBits(int a, int b) 
		{
			this.a = a;
			this.b = b;
		}
	}

	public void start(Stage primaryStage) 
	{
		try 
		{
			newFood();
			VBox vertical = new VBox();
			Canvas canvas = new Canvas(Width * windowSize, Height * windowSize);
			GraphicsContext graphics = canvas.getGraphicsContext2D();
			vertical.getChildren().add(canvas);

			new AnimationTimer() {
				long lastTick = 0;

				public void handle(long now) 
				{
					if (lastTick == 0) {
						lastTick = now;
						style(graphics);
						return;
					}

					if (now - lastTick > 1000000000 / speed) 
					{
						lastTick = now;
						style(graphics);
					}
				}

			}.start();

			Scene scene = new Scene(vertical, Width * windowSize, Height * windowSize);

			// key events to move the snake (Using WASD keys instead of arrow keys)
			// couldn't figure out how to make arrow keys work
			// received help with key events from https://docs.oracle.com/javase/7/docs/api/java/awt/event/KeyEvent.html
			scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> 
			{
				if (key.getCode() == KeyCode.W) 
				{
					direction = Dir.up;
				}
				if (key.getCode() == KeyCode.A) 
				{
					direction = Dir.left;
				}
				if (key.getCode() == KeyCode.S) 
				{
					direction = Dir.down;
				}
				if (key.getCode() == KeyCode.D) 
				{
					direction = Dir.right;
				}
			});

			// add food
			snake.add(new snakeBits(Width / 2, Height / 2));
			snake.add(new snakeBits(Width / 2, Height / 2));
			snake.add(new snakeBits(Width / 2, Height / 2));

			primaryStage.setScene(scene);
			primaryStage.setTitle("Simple Snake Game");
			primaryStage.show();
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	// settings aesthetics
	public static void style(GraphicsContext gameScreen) 
	{
		// death screen
		if (death) {
			gameScreen.setFill(Color.DARKRED);
			gameScreen.setFont(new Font("", 100));
			gameScreen.fillText("Oof", 150, 250);
			// make application end once a collision with self/walls happens
			return;
		}

		//adjustable snake size
		for (int i = snake.size() - 1; i >= 1; i--) 
		{
			snake.get(i).a = snake.get(i - 1).a;
			snake.get(i).b = snake.get(i - 1).b;
		}

		// each direction (R,L, up, down)
		switch (direction) 
		{
		case right:
			snake.get(0).a++;

			if (snake.get(0).a > Width) {
				death = true;
			}
			break; 
		case left:
			snake.get(0).a--;

			if (snake.get(0).a < 0) {
				death = true;
			}
			break;
		case up:
			snake.get(0).b--;

			if (snake.get(0).b < 0) {
				death = true;
			}
			break;
		case down:
			snake.get(0).b++;

			if (snake.get(0).b > Height) {
				death = true;
			}
			break;
		}

		// adding food to snake
		if (Food1 == snake.get(0).a && Food2 == snake.get(0).b) {
			snake.add(new snakeBits(0, 0));
			newFood();
		}

		// clashing into yourself
		for (int i = 1; i < snake.size(); i++) {
			if (snake.get(0).a == snake.get(i).a && snake.get(0).b == snake.get(i).b) {
				death = true;
			}
		}

		// background
		gameScreen.setFill(Color.GRAY);
		gameScreen.fillRect(0, 0, Width * windowSize, Height * windowSize);

		// food color
		Color foodColor = Color.LIGHTYELLOW;
		gameScreen.setFill(foodColor);
		gameScreen.fillOval(Food1 * windowSize, Food2 * windowSize, windowSize, windowSize);

		// snake
		for (snakeBits c : snake) {
			gameScreen.setFill(Color.LIGHTGREEN);
			gameScreen.fillOval(c.a * windowSize, c.b * windowSize, windowSize, windowSize);
		}
		
		// score text/position
		gameScreen.setFill(Color.BLACK);
		gameScreen.setFont(new Font("", 40));
		gameScreen.fillText("Score: " + (speed-5), 12, 35);

	}

	// "food" that snake has to clash with
	public static void newFood() 
	{
		start: while (true) 
		{
			Food1 = rando.nextInt(Width);
			Food2 = rando.nextInt(Height);

			for (snakeBits snakeFood : snake) 
			{
				if (snakeFood.a == Food1 && snakeFood.b == Food2) 
				{
					continue start;
				}
			}
			// increase speed as more food is consumed
			speed++;
			break;
		}
	}

	// begin the javafx app
	public static void main(String[] args) 
	{
		launch(args);
	}
}